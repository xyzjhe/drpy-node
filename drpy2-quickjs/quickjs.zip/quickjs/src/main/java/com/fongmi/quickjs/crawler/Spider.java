package com.fongmi.quickjs.crawler;

import android.content.Context;
import android.text.TextUtils;
import android.util.Base64;

import androidx.media3.common.util.UriUtil;

import com.fongmi.quickjs.bean.Res;
import com.fongmi.quickjs.method.Global;
import com.fongmi.quickjs.method.Local;
import com.fongmi.quickjs.utils.Module;
import com.github.catvod.utils.Asset;
import com.github.catvod.utils.Json;
import com.github.catvod.utils.Path;
import com.github.catvod.utils.Util;
import com.github.catvod.utils.log.LOG;
import com.whl.quickjs.wrapper.Function;
import com.whl.quickjs.wrapper.JSArray;
import com.whl.quickjs.wrapper.JSFunction;
import com.whl.quickjs.wrapper.JSObject;
import com.whl.quickjs.wrapper.JSUtils;
import com.whl.quickjs.wrapper.ModuleLoader;
import com.whl.quickjs.wrapper.QuickJSContext;
import com.whl.quickjs.wrapper.QuickJSException;

import org.json.JSONArray;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import dalvik.system.DexClassLoader;

public class Spider extends com.github.catvod.crawler.Spider {

    private final ExecutorService executor;
    private final DexClassLoader dex;
    private QuickJSContext ctx;
    private JSObject jsObject;
    private final String key;
    private final String api;
    private boolean cat;
    private static final String TAG = "[JS]";

    public Spider(String key, String api, DexClassLoader dex) throws Exception {
        this.executor = Executors.newSingleThreadExecutor();
        this.key = key;
        this.api = api;
        this.dex = dex;
        initializeJS();
    }

    private Object call(String func, Object... args) throws Exception {

        return executor.submit(() -> {
            try {
                JSFunction function = jsObject.getJSFunction(func);
                if (function == null) return null;
                Object ret = function.call(args);
                function.release();
                return ret;
            } catch (Throwable e) {
                LOG.e(TAG + key + " " + func, e);
                return "";
            }
        }).get();

    }

    private void callVoid(String func, Object... args) throws Exception {
        executor.submit(() -> {
            try {
                JSFunction function = jsObject.getJSFunction(func);
                if (function != null) {
                    function.callVoid(args);
                    function.release();
                }
            } catch (Throwable e) {
                LOG.e(TAG + key + " " + func, e);
            }
        }).get();
    }

    @Override
    public void init(Context context, String extend) throws Exception {
        if (cat) callVoid("init", executor.submit(() -> cfg(extend)).get());
        else
            callVoid("init", executor.submit(() -> Json.valid(extend) ? ctx.parse(extend) : extend).get());
    }

    @Override
    public String homeContent(boolean filter) throws Exception {
        return (String) call("home", filter);
    }

    @Override
    public String homeVideoContent() throws Exception {
        return (String) call("homeVod");
    }

    @Override
    public String categoryContent(String tid, String pg, boolean filter, HashMap<String, String> extend) throws Exception {
        JSObject obj = executor.submit(() -> new JSUtils<>().toObj(ctx, extend)).get();
        return (String) call("category", tid, pg, filter, obj);
    }

    @Override
    public String detailContent(List<String> ids) throws Exception {
        return (String) call("detail", ids.get(0));
    }

    @Override
    public String searchContent(String key, boolean quick) throws Exception {
        return (String) call("search", key, quick);
    }

    @Override
    public String searchContent(String key, boolean quick, String pg) throws Exception {
        return (String) call("search", key, quick, pg);
    }

    @Override
    public String playerContent(String flag, String id, List<String> vipFlags) throws Exception {
        JSArray array = executor.submit(() -> new JSUtils<>().toArray(ctx, vipFlags)).get();
        return (String) call("play", flag, id, array);
    }

    @Override
    public boolean manualVideoCheck() throws Exception {
        return (Boolean) call("sniffer");
    }

    @Override
    public boolean isVideoFormat(String url) throws Exception {
        return (Boolean) call("isVideo", url);
    }

    @Override
    public Object[] proxyLocal(Map<String, String> params) throws Exception {
        if ("catvod".equals(params.get("from"))) return executor.submit(() -> proxy2(params)).get();
        else return executor.submit(() -> proxy1(params)).get();
    }

    @Override
    public String action(String action) throws Exception {
        return (String) call("action", action);
    }

    @Override
    public void destroy() {
        try {
            call("destroy");
        } catch (Throwable e) {
            e.printStackTrace();
        }
        try {
            executor.submit(() -> {
                jsObject.release();
                ctx.destroy();
            });
        } catch (Throwable e) {
            e.printStackTrace();
        } finally {
            executor.shutdownNow();
        }
    }

    public String fixAdM3u8Ai(String url, Map<String, String> extend) throws Exception {
        JSObject obj = executor.submit(() -> new JSUtils<>().toObj(ctx, extend)).get();
        return (String) call("fixAdM3u8Ai", url, obj);
    }

    private void initializeJS() throws Exception {
        executor.submit(() -> {
            if (ctx == null) createCtx();
            if (dex != null) createDex();
            createObj();
        }).get();
    }

    private void createCtx() {
        ctx = QuickJSContext.create();

        ctx.setModuleLoader(new ModuleLoader() {
            @Override
            public boolean isBytecodeMode() {
                return true;
            }

            @Override
            public String moduleNormalizeName(String baseModuleName, String moduleName) {
                return UriUtil.resolve(baseModuleName, moduleName);
            }

            @Override
            public String getModuleStringCode(String moduleName) {
                return Module.get().fetch(moduleName);
            }

            @Override
            public byte[] getModuleBytecode(String moduleName) {
                String content = Module.get().fetch(moduleName);
                if(TextUtils.isEmpty(content)) return null;
                String spider = "__JS_SPIDER__";
                String global = "globalThis." + spider;
                content = content.replace(spider, global);
                if(api.equals(moduleName)) cat = content.contains("__jsEvalReturn");
                return ctx.compileModule(content, moduleName);
            }
        });

        ctx.setConsole(new QuickJSContext.Console() {
            @Override
            public void log(String s) {
                LOG.d(TAG + key, s);
            }

            @Override
            public void info(String s) {
                LOG.d(TAG + key, s);
            }

            @Override
            public void warn(String s) {
                LOG.d(TAG + key, s);
            }

            @Override
            public void error(String s) {
                LOG.e(TAG + key, s);
            }
        });

        Global global = new Global(executor);
        ctx.getGlobalObject().bind(global);

        JSObject local = ctx.createJSObject();
        ctx.getGlobalObject().set("local", local);
        local.bind(new Local());

        ctx.getGlobalObject().set("pd", args -> {
            try {
                if (args.length > 2) {
                    return global.pd(args[0].toString(), args[1].toString(), args[2].toString());
                }
                return global.pd(args[0].toString(), args[1].toString(), "");
            } catch (Exception e) {
                throw new QuickJSException(
                        e.getMessage());
            }
        });

        ctx.evaluate(Asset.read("js/lib/http.js"));
    }

    private void createDex() {
        try {
            JSObject obj = ctx.createJSObject();
            Class<?> clz = dex.loadClass("com.github.catvod.js.Method");
            Class<?>[] classes = clz.getDeclaredClasses();
            ctx.getGlobalObject().set("jsapi", obj);
            if (classes.length == 0) invokeSingle(clz, obj);
            if (classes.length >= 1) invokeMultiple(clz, obj);
        } catch (Throwable e) {
            //LOG.e(TAG + key, e);
        }
    }

    private void invokeSingle(Class<?> clz, JSObject jsObj) throws Throwable {
        invoke(clz, jsObj, clz.getDeclaredConstructor(QuickJSContext.class).newInstance(ctx));
    }

    private void invokeMultiple(Class<?> clz, JSObject jsObj) throws Throwable {
        for (Class<?> subClz : clz.getDeclaredClasses()) {
            Object javaObj = subClz.getDeclaredConstructor(clz).newInstance(clz.getDeclaredConstructor(QuickJSContext.class).newInstance(ctx));
            JSObject subObj = ctx.createJSObject();
            invoke(subClz, subObj, javaObj);
            jsObj.set(subClz.getSimpleName(), subObj);
        }
    }

    private void invoke(Class<?> clz, JSObject jsObj, Object javaObj) {
        for (Method method : clz.getMethods()) {
            if (!method.isAnnotationPresent(Function.class)) continue;
            invoke(jsObj, method, javaObj);
        }
    }

    private void invoke(JSObject jsObj, Method method, Object javaObj) {
        jsObj.set(method.getName(), objects -> {
            try {
                return method.invoke(javaObj, objects);
            } catch (Throwable e) {
                LOG.e(TAG + key, e);
                return null;
            }
        });
    }

    private void createObj() {
        ctx.evaluateModule(String.format(Asset.read("js/lib/spider.js"), api));
        jsObject = (JSObject) ctx.getProperty(ctx.getGlobalObject(), "__JS_SPIDER__");
    }

    private JSObject cfg(String ext) {
        JSObject cfg = ctx.createJSObject();
        cfg.set("stype", 3);
        cfg.set("skey", key);
        if (Json.invalid(ext)) cfg.set("ext", ext);
        else cfg.setObject("ext", ctx.parse(ext));
        return cfg;
    }

    private Object[] proxy1(Map<String, String> params) {
        JSObject object = new JSUtils<>().toObj(ctx, params);
        JSFunction funproxy = jsObject.getJSFunction("proxy");
        JSArray jsArray = (JSArray) funproxy.call(object);
        JSONArray array = jsArray.toJsonArray();
        funproxy.release();
        jsArray.release();

        Map<String, String> headers = array.length() > 3 ? Json.toMap(array.optString(3)) : null;
        boolean base64 = array.length() > 4 && array.optInt(4) == 1;
        Object[] result = new Object[4];
        result[0] = array.optInt(0);
        result[1] = array.optString(1);
        result[2] = getStream(array.opt(2), base64);
        result[3] = headers;
        return result;
    }

    private Object[] proxy2(Map<String, String> params) {
        String url = params.get("url");
        String header = params.get("header");
        JSArray array = new JSUtils<String>().toArray(ctx, Arrays.asList(url.split("/")));
        JSFunction funproxy = jsObject.getJSFunction("proxy");
        String json = (String) funproxy.call(array, ctx.parse(header));
        funproxy.release();

        Res res = Res.objectFrom(json);
        Object[] result = new Object[3];
        result[0] = res.getCode();
        result[1] = res.getContentType();
        result[2] = res.getStream();
        return result;
    }

    private ByteArrayInputStream getStream(Object o, boolean base64) {
        if (o instanceof JSONArray) {
            JSONArray a = (JSONArray) o;
            byte[] bytes = new byte[a.length()];
            for (int i = 0; i < a.length(); i++) bytes[i] = (byte) a.optInt(i);
            return new ByteArrayInputStream(bytes);
        } else {
            String content = String.valueOf(o);
            if (base64 && content.contains("base64,")) content = content.split("base64,")[1];
            return new ByteArrayInputStream(base64 ? Util.decode(content, Base64.DEFAULT | Base64.NO_WRAP) : content.getBytes());
        }
    }
}

