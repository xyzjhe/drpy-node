package com.fongmi.quickjs.method;

import android.net.Uri;
import android.text.TextUtils;
import android.util.Base64;

import androidx.annotation.Keep;
import androidx.annotation.NonNull;

import com.fongmi.quickjs.bean.Req;
import com.fongmi.quickjs.utils.Connect;
import com.fongmi.quickjs.utils.Crypto;
import com.fongmi.quickjs.utils.Parser;
import com.fongmi.quickjs.utils.RSAEncrypt;
import com.github.catvod.Proxy;
import com.github.catvod.net.OkHttp;
import com.github.catvod.utils.Prefers;
import com.github.catvod.utils.Trans;
import com.github.catvod.utils.Util;
import com.github.catvod.utils.log.LOG;
import com.whl.quickjs.wrapper.ContextSetter;
import com.whl.quickjs.wrapper.Function;
import com.whl.quickjs.wrapper.JSArray;
import com.whl.quickjs.wrapper.JSFunction;
import com.whl.quickjs.wrapper.JSObject;
import com.whl.quickjs.wrapper.JSUtils;
import com.whl.quickjs.wrapper.QuickJSContext;

import org.json.JSONObject;
import org.zero.brotlilib.dec.BrotliInputStream;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.security.SecureRandom;
import java.util.Enumeration;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class Global {

    private final ExecutorService executor;
    private QuickJSContext ctx;
    private final Parser parser;
    private final Timer timer;

    public static Global create(ExecutorService executor) {
        return new Global(executor);
    }

    public Global(ExecutorService executor) {
        this.parser = new Parser();
        this.executor = executor;
        this.timer = new Timer();
    }

    private void submit(Runnable runnable) {
        if (!executor.isShutdown()) executor.submit(runnable);
    }

    @Keep
    @Function
    public String s2t(String text) {
        return Trans.s2t(false, text);
    }

    @Keep
    @Function
    public String t2s(String text) {
        return Trans.t2s(false, text);
    }

    @Keep
    @Function
    public String getProxy(Boolean local) {
        return Proxy.getUrl(local) + "?do=js";
    }

    @Keep
    @Function
    public String js2Proxy(Boolean dynamic, Integer siteType, String siteKey, String url, JSObject headers) {
        try {
            return getProxy(!dynamic) + "&from=catvod" + "&siteType=" + siteType + "&siteKey=" + siteKey + "&header=" + URLEncoder.encode(headers.toJsonString(), "UTF-8") + "&url=" + URLEncoder.encode(url, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            return "";
        }
    }

    @Keep
    @Function
    public void setTimeout(JSFunction func, Integer delay) {
        func.hold();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                if (!executor.isShutdown()) executor.submit(() -> {
                    func.call();
                });
            }
        }, delay);
    }

    @Keep
    @Function
    public JSArray batchFetch(JSObject options) {
        String json = OkHttp.stringPost("http://" + Util.getIp() + ":" + Proxy.getPort() + "/bf", ((JSArray) options).toJsonArray().toString());
        return (JSArray) ctx.parse(json);
    }

    @Keep
    @Function
    public JSObject _http(String url, JSObject options) {
        JSFunction complete = options.getJSFunction("complete");
        if (complete == null) return req(url, options);
        Req req = Req.objectFrom(options.toJsonObject().toString());
        Connect.to(url, req).enqueue(getCallback(complete, req));
        return null;
    }

    @Keep
    private JSObject req(String url, JSObject options) {
        try {
            Req req = Req.objectFrom(options.toJsonObject().toString());
            Response res = Connect.to(url, req).execute();
            return Connect.success(ctx, req, res);
        } catch (Exception e) {
            return Connect.error(ctx);
        }
    }

    @Keep
    @Function
    public String praseHost(String url) {
        if (!url.contains("jiexi")) return url;
        String newurl;
        try {
            Uri uri = Uri.parse(url);
//            InetAddress[] addr = InetAddress.getAllByName(uri.getHost());
            if (IPV4First()) {
                newurl = uri.getScheme() + "://192.168.3.250:" + uri.getPort() + uri.getPath();
//                for (InetAddress i : addr) {
//                    Logger.t("hostaddr-----------").d("addr %s", i.toString());
//                    if (i instanceof Inet4Address) {
//                        newurl = uri.getScheme() + "://" + i.getHostAddress() + ":" + uri.getPort() + uri.getPath();
//                    }
//                }
            } else {
                newurl = uri.getScheme() + "://" + Prefers.getString("ipinfo", "") + ":" + uri.getPort() + uri.getPath();
//                for (InetAddress i : addr) {
//                    Logger.t("hostaddr-----------").d("addr %s", i.toString());
//                    if (i instanceof Inet6Address) {
//                        newurl = uri.getScheme() + "://[" + i.getHostAddress() + "]:" + uri.getPort() + uri.getPath();
//                    }
//                }
            }
        } catch (SocketException e) {
            return url;
        }
        return newurl;
    }

    @Keep
    private boolean IPV4First() throws SocketException {
        Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
        boolean atHome = false;
        boolean pubilcV6_access = false;
        while (networkInterfaces.hasMoreElements()) {
            NetworkInterface iface = networkInterfaces.nextElement();
            for (Enumeration<InetAddress> inetAddrs = iface.getInetAddresses(); inetAddrs.hasMoreElements(); ) {
                InetAddress inetAddr = inetAddrs.nextElement();
                if (inetAddr instanceof Inet4Address) {
                    if (Objects.requireNonNull(inetAddr.getHostAddress()).startsWith("192.168.3"))
                        atHome = true;
                } else {
                    if (Objects.requireNonNull(inetAddr.getHostAddress()).startsWith("24"))
                        pubilcV6_access = true;
                }
            }
        }
        return atHome || (!pubilcV6_access);
    }

    @Keep
    public String pd(String html, String rule, String urlKey) {
        return parser.pdfh(html, rule, urlKey);
    }

    @Keep
    @Function
    public String pdfh(String html, String rule) {
        return parser.pdfh(html, rule, "");
    }

    @Keep
    @Function
    public JSArray pdfa(String html, String rule) {
        return new JSUtils<String>().toArray(ctx, parser.pdfa(html, rule));
    }

    @Keep
    @Function
    public JSArray pdfl(String html, String rule, String texts, String urls, String urlKey) {
        return new JSUtils<String>().toArray(ctx, parser.pdfl(html, rule, texts, urls, urlKey));
    }

    @Keep
    @Function
    public String joinUrl(String parent, String child) {
        return parser.joinUrl(parent, child);
    }

    @Keep
    @Function
    public String gbkDecode(JSArray buffer) throws CharacterCodingException {
        byte[] bytes = new byte[buffer.length()];
        for (int i = 0; i < buffer.length(); i++) bytes[i] = (byte) (int) buffer.get(i);
        String result = Charset.forName("GB2312").newDecoder().decode(ByteBuffer.wrap(bytes)).toString();
        LOG.e("gbkDecode", String.format("text:%s\nresult:\n%s", buffer, result));
        return result;
    }

    @Keep
    @Function
    public static String gzipDecompress(String compressedStr) throws IOException {
        if (TextUtils.isEmpty(compressedStr)) {
            return compressedStr;
        }
        InputStream is = new ByteArrayInputStream(Util.decode(compressedStr, Base64.DEFAULT | Base64.NO_WRAP));
        GZIPInputStream gis = new GZIPInputStream(is);
        BufferedReader br = new BufferedReader(new InputStreamReader(gis, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) {
            sb.append(line);
        }
        br.close();
        return sb.toString();
    }

    @Keep
    @Function
    public static String brDecompress(String compressedStr) throws IOException {
        if (TextUtils.isEmpty(compressedStr)) {
            return compressedStr;
        }
        InputStream is = new ByteArrayInputStream(Util.decode(compressedStr, Base64.DEFAULT | Base64.NO_WRAP));
        BrotliInputStream bis = new BrotliInputStream(is);
        BufferedReader br = new BufferedReader(new InputStreamReader(bis, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) {
            sb.append(line);
        }
        br.close();
        return sb.toString();
    }

    @Keep
    @Function
    public byte[] getRandomValues(int byteLength) {
        byte[] randomBytes = new byte[byteLength];
        SecureRandom secureRandom = new SecureRandom();
        secureRandom.nextBytes(randomBytes);
        return randomBytes;
    }

    @Keep
    @Function
    public String md5X(String text) {
        String result = Crypto.md5(text);
        LOG.e("md5X", String.format("text:%s\nresult:\n%s", text, result));
        return result;
    }

    @Keep
    @Function
    public String aesX(String mode, boolean encrypt, String input, boolean inBase64, String key, String iv, boolean outBase64) {
        String result = Crypto.aes(mode, encrypt, input, inBase64, key, iv, outBase64);
        LOG.e("aesX", String.format("mode:%s\nencrypt:%s\ninBase64:%s\noutBase64:%s\nkey:%s\niv:%s\ninput:\n%s\nresult:\n%s", mode, encrypt, inBase64, outBase64, key, iv, input, result));
        return result;
    }

    @Keep
    @Function
    public String rsaX(String mode, boolean pub, boolean encrypt, String input, boolean inBase64, String key, boolean outBase64) {
        String result = Crypto.rsa(mode, pub, encrypt, input, inBase64, key, outBase64);
        LOG.e("rsaX", String.format("mode:%s\npub:%s\nencrypt:%s\ninBase64:%s\noutBase64:%s\nkey:\n%s\ninput:\n%s\nresult:\n%s", mode, pub, encrypt, inBase64, outBase64, key, input, result));
        return result;
    }

    @Keep
    @Function
    public String rsaEncrypt(String data, String key) {
        return rsaEncrypt(data, key, null);
    }

    /**
     * RSA 加密
     *
     * @param data    要加密的数据
     * @param key     密钥，type 为 1 则公钥，type 为 2 则私钥
     * @param options 加密的选项，包含加密配置和类型：{ config: "RSA/ECB/PKCS1Padding", type: 1, long: 1 }
     *                config 加密的配置，默认 RSA/ECB/PKCS1Padding （可选）
     *                type 加密类型，1 公钥加密 私钥解密，2 私钥加密 公钥解密（可选，默认 1）
     *                long 加密方式，1 普通，2 分段（可选，默认 1）
     *                block 分段长度，false 固定117，true 自动（可选，默认 true ）
     * @return 返回加密结果
     */

    @Keep
    @Function
    public String rsaEncrypt(String data, String key, JSObject options) {
        int mLong = 1;
        int mType = 1;
        boolean mBlock = true;
        String mConfig = null;
        if (options != null) {
            JSONObject op = options.toJsonObject();
            if (op.has("config")) {
                try {
                    mConfig = op.optString("config");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (op.has("type")) {
                try {
                    mType = op.optInt("type");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (op.has("long")) {
                try {
                    mLong = op.optInt("long");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (op.has("block")) {
                try {
                    mBlock = op.optBoolean("block");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        try {
            switch (mType) {
                case 1:
                    if (mConfig != null) {
                        return RSAEncrypt.encryptByPublicKey(data, key, mConfig, mLong, mBlock);
                    } else {
                        return RSAEncrypt.encryptByPublicKey(data, key, mLong, mBlock);
                    }
                case 2:
                    if (mConfig != null) {
                        return RSAEncrypt.encryptByPrivateKey(data, key, mConfig, mLong, mBlock);
                    } else {
                        return RSAEncrypt.encryptByPrivateKey(data, key, mLong, mBlock);
                    }
                default:
                    return "";
            }
        } catch (Exception e) {
            return "";
        }
    }

    @Keep
    @Function
    public String rsaDecrypt(String encryptBase64Data, String key) {
        return rsaDecrypt(encryptBase64Data, key, null);
    }

    /**
     * RSA 解密
     *
     * @param encryptBase64Data 加密后的 Base64 字符串
     * @param key               密钥，type 为 1 则私钥，type 为 2 则公钥
     * @param options           解密的选项，包含解密配置和类型：{ config: "RSA/ECB/PKCS1Padding", type: 1, long: 1 }
     *                          config 解密的配置，默认 RSA/ECB/PKCS1Padding （可选）
     *                          type 解密类型，1 公钥加密 私钥解密，2 私钥加密 公钥解密（可选，默认 1）
     *                          long 解密方式，1 普通，2 分段（可选，默认 1）
     *                          block 分段长度，false 固定128，true 自动（可选，默认 true ）
     * @return 返回解密结果
     */
    @Keep
    @Function
    public String rsaDecrypt(String encryptBase64Data, String key, JSObject options) {
        int mLong = 1;
        int mType = 1;
        boolean mBlock = true;
        String mConfig = null;
        if (options != null) {
            JSONObject op = options.toJsonObject();
            if (op.has("config")) {
                try {
                    mConfig = op.optString("config");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (op.has("type")) {
                try {
                    mType = op.optInt("type");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (op.has("long")) {
                try {
                    mLong = op.optInt("long");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (op.has("block")) {
                try {
                    mBlock = op.optBoolean("block");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        try {
            switch (mType) {
                case 1:
                    if (mConfig != null) {
                        return RSAEncrypt.decryptByPrivateKey(encryptBase64Data, key, mConfig, mLong, mBlock);
                    } else {
                        return RSAEncrypt.decryptByPrivateKey(encryptBase64Data, key, mLong, mBlock);
                    }
                case 2:
                    if (mConfig != null) {
                        return RSAEncrypt.decryptByPublicKey(encryptBase64Data, key, mConfig, mLong, mBlock);
                    } else {
                        return RSAEncrypt.decryptByPublicKey(encryptBase64Data, key, mLong, mBlock);
                    }
                default:
                    return "";
            }
        } catch (Exception e) {
            return "";
        }
    }

    private Callback getCallback(JSFunction complete, Req req) {
        return new Callback() {
            @Override
            public void onResponse(@NonNull Call call, @NonNull Response res) {
                submit(() -> {
                    complete.callVoid(Connect.success(ctx, req, res));
                    complete.release();
                });
            }

            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                submit(() -> {
                    complete.callVoid(Connect.error(ctx));
                    complete.release();
                });
            }
        };
    }

    @Keep
    // 声明用于依赖注入的 QuickJSContext
    @ContextSetter
    public void setJSContext(QuickJSContext ctx) {
        this.ctx = ctx;
    }
}
