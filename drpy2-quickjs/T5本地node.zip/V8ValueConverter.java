package com.github.catvod.crawler.node;

import android.util.Base64;

import com.caoccao.javet.exceptions.JavetException;
import com.caoccao.javet.values.V8Value;
import com.caoccao.javet.values.primitive.V8ValueBoolean;
import com.caoccao.javet.values.primitive.V8ValueDouble;
import com.caoccao.javet.values.primitive.V8ValueInteger;
import com.caoccao.javet.values.primitive.V8ValuePrimitive;
import com.caoccao.javet.values.primitive.V8ValueString;
import com.caoccao.javet.values.reference.IV8ValueArray;
import com.caoccao.javet.values.reference.IV8ValueObject;
import com.caoccao.javet.values.reference.V8ValueArray;
import com.caoccao.javet.values.reference.V8ValueArrayBuffer;
import com.caoccao.javet.values.reference.V8ValueObject;
import com.caoccao.javet.values.reference.V8ValueTypedArray;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class V8ValueConverter {
    public static String v8ValueToString(Object value) throws JavetException {
        if (value == null) return "null";

        // 1. 已转换的 Java 类型
        if (value instanceof Map || value instanceof List || value instanceof String ||
                value instanceof Number || value instanceof Boolean) {
            return value.toString();
        }

        // 2. 二进制转 Base64
        if (value instanceof ByteBuffer) {
            ByteBuffer bb = (ByteBuffer) value;
            byte[] bytes = new byte[bb.remaining()];
            bb.get(bytes);
            return Base64.encodeToString(bytes, Base64.DEFAULT);
        }
        if (value instanceof byte[]) {
            return Base64.encodeToString((byte[]) value, Base64.DEFAULT);
        }

        // 3. 原生 V8Value（无 Converter）
        if (value instanceof V8Value) {
            V8Value v8 = (V8Value) value;
            try {
                if (v8 instanceof V8ValuePrimitive) {
                    return v8.toString();  // 数字、布尔、字符串
                }
                if (v8 instanceof V8ValueObject) {
                    // 对象转 JSON
                    return ((V8ValueObject)v8).toJsonString();  // V8 原生 JSON 序列化
                }
                return v8.toString();
            } finally {
                v8.close();  // 释放资源
            }
        }

        return String.valueOf(value);
    }
    // V8Value → Java Object
    public static Object toJavaObject(V8Value v8Value) throws JavetException {
        if (v8Value == null || v8Value.isUndefined() || v8Value.isNull()) {
            return null;
        }

        if (v8Value instanceof V8ValuePrimitive) {
            if (v8Value instanceof V8ValueString) {
                return ((V8ValueString) v8Value).getValue();
            }
            if (v8Value instanceof V8ValueInteger) {
                return ((V8ValueInteger) v8Value).getValue();
            }
            if (v8Value instanceof V8ValueDouble) {
                return ((V8ValueDouble) v8Value).getValue();
            }
            if (v8Value instanceof V8ValueBoolean) {
                return ((V8ValueBoolean) v8Value).getValue();
            }
        }

        if (v8Value instanceof V8ValueArray) {
            V8ValueArray array = (V8ValueArray) v8Value;
            List<Object> list = new ArrayList<>();
            for (int i = 0; i < array.getLength(); i++) {
                list.add(toJavaObject(array.get(i)));
            }
            return list;
        }

        if (v8Value instanceof V8ValueObject) {
            V8ValueObject obj = (V8ValueObject) v8Value;

            // 检测是否为 TypedArray/Buffer
            if (isBinary(obj)) {
                return extractBytes(obj);
            }

            // 普通对象转 Map
            Map<String, Object> map = new HashMap<>();
            IV8ValueArray keys = obj.getOwnPropertyNames();
            for (int i = 0; i < keys.getLength(); i++) {
                String key = keys.getString(i);
                map.put(key, toJavaObject(obj.get(key)));
            }
            keys.close();
            return map;
        }
        return v8Value.toString();
    }

    private static boolean isBinary(IV8ValueObject obj) throws JavetException {
        return obj.has("byteLength") ||
                obj.has("buffer") ||
                obj.has("BYTES_PER_ELEMENT");
    }

    private static byte[] extractBytes(V8ValueTypedArray typedArray) throws JavetException {
        return typedArray.toBytes();
    }

    private static byte[] extractBytes(V8ValueArrayBuffer buffer) {
        return buffer.toBytes();
    }

    private static byte[] extractBytes(V8ValueObject buffer) throws JavetException {
        if (buffer instanceof V8ValueTypedArray) {
            return extractBytes((V8ValueTypedArray) buffer);
        }
        if (buffer instanceof V8ValueArrayBuffer) {
            return extractBytes((V8ValueArrayBuffer) buffer);
        }
        return null;
    }
}