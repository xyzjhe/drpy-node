package com.github.catvod.crawler.node;

import static com.github.tvbox.osc.server.RemoteServer.getRootPath;

import android.net.Uri;
import android.text.TextUtils;

import com.caoccao.javet.enums.JSRuntimeType;
import com.caoccao.javet.interop.NodeRuntime;
import com.caoccao.javet.interop.loader.IJavetLibLoadingListener;
import com.caoccao.javet.interop.loader.JavetLibLoader;
import com.caoccao.javet.interop.options.NodeRuntimeOptions;
import com.caoccao.javet.interop.options.V8Flags;
import com.github.catvod.crawler.Spider;
import com.github.catvod.crawler.SpiderNull;
import com.github.catvod.crawler.js.Module;
import com.github.tvbox.osc.api.ApiConfig;
import com.github.tvbox.osc.base.App;
import com.github.tvbox.osc.bean.SourceBean;
import com.github.tvbox.osc.plugin.NodeHttpServerController;
import com.github.tvbox.osc.util.HawkConfig;
import com.github.tvbox.osc.util.LOG;
import com.github.tvbox.osc.util.MD5;
import com.github.tvbox.osc.util.Path;
import com.github.tvbox.osc.util.net.OkHttp;
import com.google.common.net.HttpHeaders;
import com.orhanobut.hawk.Hawk;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import okhttp3.Headers;
import okhttp3.Response;

public class NodeLoader {
    private static final String TAG = "NodeJs";
    private static NodeLoader instance;
    private static NodeServerController node;
    private final ConcurrentHashMap<String, Spider> spiders;
    private String recent;
    public NodeLoader() {
        spiders = new ConcurrentHashMap<>();
    }

    public static NodeLoader get() {
        if (instance == null) {
            synchronized (ApiConfig.class) {
                if (instance == null) {
                    instance = new NodeLoader();
                }
            }
        }
        return instance;
    }

    public void clear() {
        for (Spider spider : spiders.values()) spider.destroy();
        spiders.clear();
    }

    public Spider getSpider(String key, String api, String ext) {
        try {
            NodeRuntime ctx = getNode().getNodeRuntime();
            if (spiders.containsKey(key)) return spiders.get(key);

            if (api.matches("https?://.+\\.js")) {
                api = Module.get().nodeFetchToCache(api).replaceAll("\\.js$", "");
            }
            if (api.isEmpty()) {
                return new SpiderNull();
            }

            Spider spider = new NodeSpider(key, api, ctx);
            spider.init(App.getInstance(), ext);
            spiders.put(key, spider);
            return spider;
        } catch (Throwable e) {
            e.printStackTrace();
            return new SpiderNull();
        }
    }

    public NodeServerController getNode() {
        if (node == null || !node.isRunning()) {
            node = null;
            initNode();
        }
        return node;
    }

    public void initNode() {
        if (!NodeHttpServerController.updateLibraryFromSDCard()) {
            LOG.e(TAG, "没有Node库文件");
            return;
        }

        JavetLibLoader.setLibLoadingListener(new IJavetLibLoadingListener() {
            @Override
            public File getLibPath(JSRuntimeType jsRuntimeType) {
                File libPath = new File(App.getInstance().getFilesDir(), "plugin/node");
                LOG.i(TAG, "getLibPath: " + libPath);
                return libPath;
            }

            @Override
            public boolean isDeploy(JSRuntimeType jsRuntimeType) {
                return false;
            }

            @Override
            public boolean isLibInSystemPath(JSRuntimeType jsRuntimeType) {
                return false;
            }

            @Override
            public boolean isSuppressingError(JSRuntimeType jsRuntimeType) {
                return true;
            }
        });

        V8Flags v8Flags = NodeRuntimeOptions.V8_FLAGS;
        v8Flags.setUseStrict(false);

        long startTime = System.currentTimeMillis();
        CountDownLatch countDownLatch = new CountDownLatch(1);
        node = null;
        node = new NodeServerController();
        HeavyTaskUtil.executeNewTask(() -> {
            node.startServer(getRootPath() + "/drpy-node", new NodeServerController.StateListener() {
                @Override
                public void state(boolean running) {
                    if (running) {
                        countDownLatch.countDown();
                    }
                }
            });
        });

        try {
            countDownLatch.await(10, TimeUnit.SECONDS);
            LOG.w(TAG, "node启动时间:", System.currentTimeMillis() - startTime);
        } catch (InterruptedException e) {
            LOG.w(TAG, "源等待node启动超时:", e);
        }
    }

    public Object[] proxyInvoke(Map<String, String> params) {
        try {
            Map<String, String> treeParams = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
            treeParams.putAll(params);
            String sourceKey = treeParams.get("sourcekey");
            if (sourceKey == null) sourceKey = treeParams.get("siteKey");
            if (sourceKey == null) sourceKey = ApiConfig.get().getHomeSourceBean().getKey();

            if (!TextUtils.isEmpty(sourceKey)) {
                if (!spiders.containsKey(sourceKey)) {
                    SourceBean sb = ApiConfig.get().getSource(sourceKey);
                    if (sb != null) {
                        ApiConfig.get().getCSP(sb);
                    }
                }
            }
            if (!spiders.containsKey(sourceKey)) {
                return null;
            }

            Spider sp = spiders.get(sourceKey);
            if (sp != null) {
                final Object[][] obj = {null};
                CountDownLatch countDownLatch = new CountDownLatch(1);
                HeavyTaskUtil.executeNewTask(() -> {
                    try {
                        sp.proxyLocal(params, new Spider.ResultListener() {
                            @Override
                            public void result(Object[] result) {
                                obj[0] = result;
                                countDownLatch.countDown();
                            }

                            @Override
                            public void error(String error) {
                                obj[0] = null;
                                countDownLatch.countDown();
                            }
                        });
                    } catch (Exception e) {
                        LOG.w(TAG, "代理错误:", e);
                        obj[0] = null;
                        countDownLatch.countDown();
                    }
                });

                try {
                    countDownLatch.await(15, TimeUnit.SECONDS);
                    return obj[0];
                } catch (InterruptedException e) {
                    LOG.w(TAG, "源等待node代理超时:", e);
                }
            }
        } catch (Throwable th) {
            LOG.e("proxyInvoke", th);
        }
        return null;
    }

}
