package com.github.catvod.crawler.node;

import android.content.Context;
import android.util.Base64;

import com.caoccao.javet.exceptions.JavetException;
import com.caoccao.javet.interop.NodeRuntime;
import com.caoccao.javet.values.V8Value;
import com.caoccao.javet.values.reference.IV8ValuePromise;
import com.caoccao.javet.values.reference.V8ValueArray;
import com.caoccao.javet.values.reference.V8ValueFunction;
import com.caoccao.javet.values.reference.V8ValueObject;
import com.caoccao.javet.values.reference.V8ValuePromise;
import com.github.catvod.crawler.Spider;
import com.github.catvod.crawler.js.Json;
import com.github.tvbox.osc.server.ControlManager;
import com.github.tvbox.osc.server.RemoteServer;
import com.github.tvbox.osc.util.LOG;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class NodeSpider extends Spider {
    private final String sourceKey;
    private final String modulePath;
    private final NodeRuntime nodeRuntime;
    ConcurrentHashMap<String, String> queryMap;
    V8ValueObject params;

    public NodeSpider(String key, String path, NodeRuntime ctx) throws JavetException {
        this.sourceKey = key;
        this.modulePath = path;
        this.nodeRuntime = ctx;
        this.queryMap = new ConcurrentHashMap<>();
        this.params = nodeRuntime.createV8ValueObject();
    }

    private void func(ResultListener listener, Object... args) {
        try {
            V8ValueFunction v8ValueFunction = nodeRuntime.getGlobalObject().get("getEngine");
            Object result = v8ValueFunction.call(null, args);
            if (result instanceof V8ValuePromise) {
                V8ValuePromise v8ValuePromise = ((V8ValuePromise) result);
                v8ValuePromise.register(new IV8ValuePromise.IListener() {
                    @Override
                    public void onFulfilled(V8Value v8Value) {
                        if (listener != null) {
                            try {
//                                LOG.w("测试", "res:", v8Value.getClass().getName());
                                if (v8Value instanceof V8ValueArray) {
                                    List<Object> data = (List<Object>) V8ValueConverter.toJavaObject(v8Value);

                                    Map<String, String> headers = data.size() > 3 ? Json.toMap(new Gson().toJson(data.get(3))) : null;
                                    boolean base64 = data.size() > 4 && (int)data.get(4) == 1;

                                    Object[] res = new Object[4];
                                    res[0] = data.get(0);
                                    res[1] = data.get(1);
                                    res[2] = getStream(data.get(2), base64);
                                    res[3] = headers;
                                    listener.result(res);
                                } else {
                                    listener.result(V8ValueConverter.v8ValueToString(v8Value));
                                }
                            } catch (Exception e) {
                                LOG.e("NodeSpider", e);
                                listener.error(e.getMessage());
                            }
                        }
                    }

                    @Override
                    public void onCatch(V8Value v8Value) {
                        listener.error(((V8ValueObject) v8Value).toJsonString());
                    }

                    @Override
                    public void onRejected(V8Value v8Value) {
                        listener.error(((V8ValueObject) v8Value).toJsonString());
                    }
                });
            } else {
                LOG.w("测试", "instanceof:Other");
                if (listener != null) {
                    try {
                        listener.result(V8ValueConverter.v8ValueToString(result));
                    } catch (JavetException e) {
                        listener.result("");
                    }
                }
            }
        } catch (Throwable throwable) {
            LOG.e(throwable);
            if (listener != null) {
                listener.error(throwable.getMessage());
            }
        }
    }

    private ByteArrayInputStream getStream(Object o, boolean base64) {
        if (o instanceof byte[]) {
            return new ByteArrayInputStream((byte[])o);
        } else {
            String content = String.valueOf(o);
            if (base64 && content.contains("base64,")) content = content.split("base64,")[1];
            return new ByteArrayInputStream(base64 ? Base64.decode(content, Base64.DEFAULT | Base64.NO_WRAP) : content.getBytes());
        }
    }

    @Override
    public void init(Context context) {
        super.init(context);
    }

    @Override
    public void init(Context context, String extend) throws Exception {
        super.init(context, extend);
        try {
            String go = "ds";
            boolean refresh = false;
            if (extend.startsWith("{")) {
                JSONObject json = new JSONObject(extend);
                extend = json.optString("extend", "");
                go = json.optString("do", "ds");
                refresh = json.optBoolean("refresh", false);
            }
            queryMap.put("do", go);
            if(refresh) queryMap.put("refresh", "");
            queryMap.put("extend", extend);

            params.set("sitekey", sourceKey);
            params.set("port", RemoteServer.serverPort);
            params.set("proxyUrl", ControlManager.get().getAddress(true) + "proxy?siteKey=" + sourceKey);
        } catch (Throwable throwable) {
            LOG.e(throwable);
        }
    }

    @Override
    public String categoryContent(String tid, String pg, boolean filter, HashMap<String, String> extend, ResultListener listener) {
        try {
            V8ValueObject ext = nodeRuntime.createV8ValueObject();
            if (extend != null) {
                for (String s : extend.keySet()) {
                    ext.set(s, extend.get(s));
                }
            }
            V8ValueObject query = nodeRuntime.createV8ValueObject();
            if (queryMap != null) {
                for (String s : queryMap.keySet()) {
                    query.set(s, queryMap.get(s));
                }
            }
            query.set("ac", "category");
            query.set("t", tid);
            query.set("pg", pg);
            query.set("ext", ext);
            func(listener, modulePath, query, params);
        } catch (Throwable throwable) {
            LOG.e(throwable);
            if (listener != null) {
                listener.error(throwable.getMessage());
            }
        }
        return "";
    }

    @Override
    public String detailContent(List<String> list, ResultListener listener) {
        try {
            V8ValueArray array = nodeRuntime.createV8ValueArray();
            if (list != null) {
                for (int i = 0; i < list.size(); i++) {
                    array.push(list.get(i));
                }
            }
            V8ValueObject query = nodeRuntime.createV8ValueObject();
            if (queryMap != null) {
                for (String s : queryMap.keySet()) {
                    query.set(s, queryMap.get(s));
                }
            }
            query.set("ac", "detail");
            query.set("ids", array);
            func(listener, modulePath, query, params);
        } catch (Throwable throwable) {
            LOG.e(throwable);
            if (listener != null) {
                listener.error(throwable.getMessage());
            }
        }
        return "";
    }

    @Override
    public String homeContent(boolean filter, ResultListener listener) {
        try {
            V8ValueObject query = nodeRuntime.createV8ValueObject();
            if (queryMap != null) {
                for (String s : queryMap.keySet()) {
                    query.set(s, queryMap.get(s));
                }
            }
            query.set("filter", filter);
            func(listener, modulePath, query, params);
        } catch (Throwable throwable) {
            LOG.e(throwable);
            if (listener != null) {
                listener.error(throwable.getMessage());
            }
        }
        return "";
    }

    @Override
    public String homeVideoContent(ResultListener listener) {
        try {
            V8ValueObject query = nodeRuntime.createV8ValueObject();
            if (queryMap != null) {
                for (String s : queryMap.keySet()) {
                    query.set(s, queryMap.get(s));
                }
            }
            func(listener, modulePath, query, params);
        } catch (Throwable throwable) {
            LOG.e(throwable);
            if (listener != null) {
                listener.error(throwable.getMessage());
            }
        }
        return "";
    }

    @Override
    public String playerContent(String flag, String id, List<String> vipFlags, ResultListener listener) {
        try {
            V8ValueArray array = nodeRuntime.createV8ValueArray();
            if (vipFlags != null) {
                for (int i = 0; i < vipFlags.size(); i++) {
                    array.push(vipFlags.get(i));
                }
            }
            V8ValueObject query = nodeRuntime.createV8ValueObject();
            if (queryMap != null) {
                for (String s : queryMap.keySet()) {
                    query.set(s, queryMap.get(s));
                }
            }
            query.set("play", id);
            query.set("flag", flag);
            func(listener, modulePath, query, params);
        } catch (Throwable throwable) {
            LOG.e(throwable);
            if (listener != null) {
                listener.error(throwable.getMessage());
            }
        }
        return "";
    }

    @Override
    public String searchContent(String key, boolean quick, ResultListener listener) {
        try {
            V8ValueObject query = nodeRuntime.createV8ValueObject();
            if (queryMap != null) {
                for (String s : queryMap.keySet()) {
                    query.set(s, queryMap.get(s));
                }
            }
            query.set("wd", key);
            query.set("quick", quick);
            func(listener, modulePath, query, params);
        } catch (Throwable throwable) {
            LOG.e(throwable);
            if (listener != null) {
                listener.error(throwable.getMessage());
            }
        }
        return "";
    }

    @Override
    public String searchContent(String key, boolean quick, String pg, ResultListener listener) {
        try {
            V8ValueObject query = nodeRuntime.createV8ValueObject();
            if (queryMap != null) {
                for (String s : queryMap.keySet()) {
                    query.set(s, queryMap.get(s));
                }
            }
            query.set("wd", key);
            query.set("quick", quick);
            query.set("pg", pg);
            func(listener, modulePath, query, params);
        } catch (Throwable throwable) {
            LOG.e(throwable);
            if (listener != null) {
                listener.error(throwable.getMessage());
            }
        }
        return "";
    }

    @Override
    public String action(String action, ResultListener listener) {
        try {
            V8ValueObject query = nodeRuntime.createV8ValueObject();
            if (queryMap != null) {
                for (String s : queryMap.keySet()) {
                    query.set(s, queryMap.get(s));
                }
            }
            query.set("ac", action);
            query.set("action", action);
            query.set("value", "");
            func(listener, modulePath, query, params);
        } catch (Throwable throwable) {
            LOG.e(throwable);
            if (listener != null) {
                listener.error(throwable.getMessage());
            }
        }
        return "";
    }

    @Override
    public String action(String action, String value, ResultListener listener) {
        try {
            V8ValueObject query = nodeRuntime.createV8ValueObject();
            if (queryMap != null) {
                for (String s : queryMap.keySet()) {
                    query.set(s, queryMap.get(s));
                }
            }
            query.set("action", action);
            query.set("ac", action);
            query.set("value", value);
            func(listener, modulePath, query, params);
        } catch (Throwable throwable) {
            LOG.e(throwable);
            if (listener != null) {
                listener.error(throwable.getMessage());
            }
        }
        return "";
    }

    @Override
    public Object[] proxyLocal(Map< String, String > requestParams, ResultListener listener) {
        try {
            V8ValueObject query = nodeRuntime.createV8ValueObject();
            if (queryMap != null) {
                for (String s : queryMap.keySet()) {
                    query.set(s, queryMap.get(s));
                }
            }
            if (requestParams != null) {
                for (String s : requestParams.keySet()) {
                    if (s.equals("request-headers")) {
                        query.set("headers", requestParams.get(s));
                    } else {
                        query.set(s, requestParams.get(s));
                    }
                }
            }
            query.set("proxy", "proxy");
            func(listener, modulePath, query, params);
        } catch (Throwable throwable) {
            LOG.e(throwable);
            if (listener != null) {
                listener.error(throwable.getMessage());
            }
        }
        return null;
    }
}
