
public class SourceViewModel extends ViewModel {

    public void action(String sourceKey, String action, String value, int timeout) {
        SourceBean sourceBean = ApiConfig.get().getSource(sourceKey);
        if (sourceBean == null) return;

        int sbType = sourceBean.getType();
        if (sbType == 5) {
            spThreadPool.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        Spider sp = ApiConfig.get().getCSP(sourceBean);
                        sp.action(action, value == null ? "" : value, new Spider.ResultListener() {
                            @Override
                            public void result(String result) {
                                if (result != null) {
                                    if (AES.isJsonObject(result)) {
                                        JsonObject obj = new Gson().fromJson(result, JsonObject.class);
                                        if (obj.has("action") && !obj.has("sourceKey")) {
                                            obj.addProperty("sourceKey", sourceKey);
                                            result = new Gson().toJson(obj);
                                        }
                                    }
                                }
                                actionResult.postValue(result);
                            }
                        });
                    } catch (Throwable th) {
                        th.printStackTrace();
                        actionResult.postValue(null);
                    }
                }
            });
        }
    }

    public void getSort(String sourceKey, String param) {
            
			if (type == 5) {
                spThreadPool.execute(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Spider sp = ApiConfig.get().getCSP(sourceBean);
                            sp.homeContent(true, new Spider.ResultListener() {
                                @Override
                                public void result(String result) {
                                    if (result == null) {
                                        result = "{\"class\":[]}";
                                        LOG.e("首页数据", "原始数据null，处理为：", result);
                                    }
                                    AbsSortXml sortXml = sortJson(sortResult, result);
                                    if (sortXml != null) sortXml.sourceKey = sourceKey;
                                    if (sortXml != null && needHomeVideoList) {
                                        AbsXml absXml = json(null, result, sourceBean.getKey());
                                        if (absXml != null && absXml.movie != null && absXml.movie.videoList != null && !absXml.movie.videoList.isEmpty()) {
                                            sortXml.videoList = absXml.movie.videoList;
                                            sortXml.flag = absXml.flag;
                                            if (finalNeedPostValue) {
                                                sortResult.postValue(sortXml);
                                            }
                                            RoomDataManger.insertSourceDataCacheRecord(sourceKey, sourceDataCacheKey, new Gson().toJson(sortXml), 1);
                                        } else {
                                            getHomeRecList(sourceBean, null, new HomeRecCallback() {
                                                @Override
                                                public void done(List<Movie.Video> videos) {
                                                    sortXml.videoList = videos;
                                                    RoomDataManger.insertSourceDataCacheRecord(sourceKey, sourceDataCacheKey, new Gson().toJson(sortXml), 1);
                                                    if (finalNeedPostValue) {
                                                        sortResult.postValue(sortXml);
                                                    }
                                                }
                                            });
                                        }
                                    } else {
                                        if (finalNeedPostValue) {
                                            sortResult.postValue(sortXml);
                                        }
                                        RoomDataManger.insertSourceDataCacheRecord(sourceKey, sourceDataCacheKey, new Gson().toJson(sortXml), 1);
                                    }
                                }
                            });
                        } catch (Exception e) {
                            LOG.e("NODE_TEST", "getSort:", e);
                            if (finalNeedPostValue) {
                                sortResult.postValue(null);
                            }
                        }
                    }
                });
            }
    }

    public void getList(MovieSort.SortData sortData, int page, String sourceKey) {
			if (type == 5) {
                spThreadPool.execute(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Spider sp = ApiConfig.get().getCSP(sourceBean);
                            sp.categoryContent(finalSortDataId, page + "", true, sortData.filterSelect, new Spider.ResultListener() {
                                @Override
                                public void result(String result) {
                                    if (TextUtils.isEmpty(result)) {
                                        if (finalNeedPostValue) {
                                            listResult.postValue(null);
                                        }
                                    } else {
                                        if (finalNeedPostValue) {
                                            json(listResult, result, sourceBean.getKey());
                                        }
                                        RoomDataManger.insertSourceDataCacheRecord(finalSourceKey, sourceDataCacheKey, result, 2);
                                    }
                                }
                            });
                        } catch (Exception e) {
                            LOG.e("NODE_TEST", "getHomeRecList:", e);
                            if (finalNeedPostValue) {
                                listResult.postValue(null);
                            }
                        }
                    }
                });
            }
    }

    void getHomeRecList(SourceBean sourceBean, ArrayList<String> ids, HomeRecCallback callback) {
            if (type == 5) {
                spThreadPool.execute(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Spider sp = ApiConfig.get().getCSP(sourceBean);
                            sp.homeVideoContent(new Spider.ResultListener() {
                                @Override
                                public void result(String result) {
                                    if (result != null) {
                                        AbsXml absXml = json(null, result, sourceBean.getKey());
                                        if (absXml != null && absXml.movie != null && absXml.movie.videoList != null) {
                                            callback.done(absXml.movie.videoList);
                                        } else {
                                            callback.done(null);
                                        }
                                    } else {
                                        callback.done(null);
                                    }
                                }
                            });
                        } catch (Exception e) {
                            LOG.e("NODE_TEST", "getHomeRecList:", e);
                            callback.done(null);
                        }
                    }
                });
            }
    }


    public void getDetail(String sourceKey, String id) {
            if (type == 5) {
                spThreadPool.execute(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Spider sp = ApiConfig.get().getCSP(sourceBean);
                            List<String> ids = new ArrayList<>();
                            ids.add(finalId);
                            sp.detailContent(ids, new Spider.ResultListener() {
                                @Override
                                public void result(String result) {
                                    if (TextUtils.isEmpty(result)) {
                                        if (finalNeedPostValue) {
                                            detailResult.postValue(null);
                                        }
                                    } else {
                                        if (finalNeedPostValue) {
                                            json(detailResult, result, sourceBean.getKey());
                                        }
                                        RoomDataManger.insertSourceDataCacheRecord(finalSourceKey, sourceDataCacheKey, result, 3);
                                    }
                                }
                            });
                        } catch (Exception e) {
                            LOG.e("NODE_TEST", "getHomeRecList:", e);
                            if (finalNeedPostValue) {
                                detailResult.postValue(null);
                            }
                        }
                    }
                });
            }
    }

    public void getSearch(String sourceKey, String wd, String page) {
            if (type == 5) {
                if (license == null || !license[0].equals(DeviceInfoUtils.getDevId()) || !md5License.equals(license[3]) || System.currentTimeMillis() > dateLicense) {
                    detailResult.postValue(null);
                    return;
                }
                spThreadPool.execute(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Spider sp = ApiConfig.get().getCSP(sourceBean);
                            if (page == null) {
                                sp.searchContent(wd, false, new Spider.ResultListener() {
                                    @Override
                                    public void result(String result) {
                                        if (!TextUtils.isEmpty(result)) {
                                            json(searchResult, result, sourceBean.getKey());
                                        } else {
                                            EventBus.getDefault().post(new RefreshEvent(RefreshEvent.TYPE_SEARCH_RESULT, null));
                                        }
                                    }
                                });
                            } else {
                                sp.searchContent(wd, false, page, new Spider.ResultListener() {
                                    @Override
                                    public void result(String result) {
                                        if (!TextUtils.isEmpty(result)) {
                                            json(searchResult, result, sourceBean.getKey());
                                        } else {
                                            EventBus.getDefault().post(new RefreshEvent(RefreshEvent.TYPE_SEARCH_RESULT, null));
                                        }
                                    }
                                });
                            }
                        } catch (Exception e) {
                            LOG.e("NODE_TEST", "getHomeRecList:", e);
                            EventBus.getDefault().post(new RefreshEvent(RefreshEvent.TYPE_SEARCH_RESULT, null));
                        }
                    }
                });
            }
    }


    public void getPlay(String sourceKey, String oriPlayFlag, String progressKey, String oriUrl, String subtitleKey) {

            if (type == 5) {
                spThreadPool.execute(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Spider sp = ApiConfig.get().getCSP(sourceBean);
                            sp.playerContent(playFlag, AESUtils.aesDecrypt(finalUrl, SignatureChecker.getSignatureFingerprint()), ApiConfig.get().getVipParseFlags(), new Spider.ResultListener() {
                                @Override
                                public void result(String result) {
                                    if (TextUtils.isEmpty(result)) {
                                        playResult.postValue(null);
                                        return;
                                    }

                                    LOG.i("原始数据", "来源：播放\n", result);

                                    try {
                                        JSONObject obj = new JSONObject(result);
                                        if (obj.has("url") && obj.get("url") instanceof JSONArray) {
                                            JSONArray urls = obj.getJSONArray("url");
                                            obj.put("urls", urls);
                                            for (int i = 0; i < urls.length(); i++) {
                                                if (urls.getString(i).startsWith("http")) {
                                                    obj.put("url", urls.getString(i));
                                                    break;
                                                }
                                            }
                                        }
                                        obj.put("key", url);
                                        obj.put("proKey", progressKey);
                                        obj.put("subtKey", subtitleKey);
                                        obj.put("playFlag", playFlag);
                                        if (!obj.has("flag"))
                                            obj.put("flag", playFlag);
                                        playResult.postValue(obj);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                        playResult.postValue(null);
                                    }
                                }
                            });
                        } catch (Exception e) {
                            LOG.e("NODE_TEST", "getHomeRecList:", e);
                            playResult.postValue(null);
                        }
                    }
                });
            }
    }
