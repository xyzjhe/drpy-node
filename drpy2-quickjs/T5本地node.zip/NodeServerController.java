package com.github.catvod.crawler.node;

import static com.lzy.okgo.utils.HttpUtils.runOnUiThread;

import android.text.TextUtils;
import android.widget.Toast;

import com.caoccao.javet.enums.JSRuntimeType;
import com.caoccao.javet.enums.JavetPromiseRejectEvent;
import com.caoccao.javet.enums.V8AwaitMode;
import com.caoccao.javet.exceptions.JavetException;
import com.caoccao.javet.interop.NodeRuntime;
import com.caoccao.javet.interop.V8Host;
import com.caoccao.javet.interop.V8Runtime;
import com.caoccao.javet.interop.callback.IJavetPromiseRejectCallback;
import com.caoccao.javet.interop.callback.IV8ModuleResolver;
import com.caoccao.javet.interop.callback.JavetBuiltInModuleResolver;
import com.caoccao.javet.interop.converters.JavetProxyConverter;
import com.caoccao.javet.interop.executors.IV8Executor;
import com.caoccao.javet.interop.options.NodeRuntimeOptions;
import com.caoccao.javet.node.modules.NodeModuleModule;
import com.caoccao.javet.node.modules.NodeModuleProcess;
import com.caoccao.javet.values.V8Value;
import com.caoccao.javet.values.reference.IV8Module;
import com.caoccao.javet.values.reference.V8ValueObject;
import com.caoccao.javet.values.reference.V8ValuePromise;
import com.github.tvbox.osc.base.App;
import com.github.tvbox.osc.plugin.keep.NodeConsole;
import com.github.tvbox.osc.plugin.keep.NodeLog;
import com.github.tvbox.osc.util.FileUtils;
import com.github.tvbox.osc.util.LOG;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;
import java.util.concurrent.atomic.AtomicBoolean;

public class NodeServerController {
    private static final String TAG = "NodeJs";
    private static final String TAG2 = "NodeImp";
    private NodeRuntime nodeRuntime;
    private static final int OUTER_TIMER_INTERVAL = 60000; // 外层60秒定时器
    private static final int BASE_WAIT_TIME = 50;          // 基础等待50ms
    private static final int MAX_CONSECUTIVE_IDLE = (OUTER_TIMER_INTERVAL / BASE_WAIT_TIME) * 2;

    private final AtomicBoolean isWorking = new AtomicBoolean(false);
    private final AtomicBoolean runState = new AtomicBoolean(false);
    private final Object lock = new Object();
    private int consecutiveIdleCycles = 0;
    private long lastWorkTimestamp = System.currentTimeMillis();
    Map<String, IV8Module> moduleCacheMap = new HashMap<>();

    private StateListener listener;

    public NodeServerController() {
    }

    public NodeRuntime getNodeRuntime() {
        return nodeRuntime;
    }

    public boolean isRunning() {
        return isWorking.get();
    }

    public interface StateListener {
        void state(boolean running);
    }

    public void startServer(String project, StateListener listener) {
        this.listener = listener;
        if (isWorking.get()) {
            LOG.e(TAG, "服务运行中: " + project);
            return;
        } else if (nodeRuntime != null) {
            LOG.e(TAG, "服务停止动作还未完成: " + project);
            isWorking.set(false);
            Toast.makeText(App.getInstance(),  "服务还未结束", Toast.LENGTH_SHORT).show();
            return;
        }
        isWorking.set(true);
        internalNodeJSWrapper(project);
    }

    public void stopServer() {
        isWorking.set(false);
    }

    private NodeRuntime createRuntime(String project, String resourceName) {
        try {
            File localRelativePath = new File(project);
            LOG.w(TAG, "createV8Runtime");
            NodeRuntimeOptions.V8_FLAGS.setUseStrict(false);
            NodeRuntimeOptions.NODE_FLAGS.setExperimentalSqlite(true);
            NodeRuntimeOptions.NODE_FLAGS.setNoWarnings(true);
            NodeRuntimeOptions.NODE_FLAGS.setCustomFlags(new String[]{"--max-old-space-size=1536", "--max-semi-space-size=48", "--stack-size=1280", "--experimental-vm-modules", "--experimental-wasm-modules", "--incremental-marking", "--concurrent-marking", "--parallel-scavenge"});
            NodeRuntimeOptions opt = new NodeRuntimeOptions();
            // NodeRuntime nodeRuntime = V8Host.getInstance(JSRuntimeType.NodeI18n).createV8Runtime(opt);
            NodeRuntime nodeRuntime = V8Host.getInstance(JSRuntimeType.Node).createV8Runtime(opt);
            nodeRuntime.setLogger(new NodeLog());

            V8ValueObject console = nodeRuntime.getExecutor("console").execute();
            console.bind(new NodeConsole());

            nodeRuntime.setPromiseRejectCallback(new IJavetPromiseRejectCallback() {
                @Override
                public void callback(JavetPromiseRejectEvent event, V8ValuePromise promise, V8Value value) {
                    LOG.e(TAG, "Rejected reason: " + value.toString());
                }
            });
            nodeRuntime.allowEval(true);
            nodeRuntime.setStopping(true);
            nodeRuntime.setConverter(new JavetProxyConverter());;

            nodeRuntime.getGlobalObject().setProperty(NodeRuntime.PROPERTY_DIRNAME, localRelativePath.getAbsolutePath());
            nodeRuntime.getGlobalObject().setProperty(NodeRuntime.PROPERTY_FILENAME, resourceName);
            nodeRuntime.getNodeModule(NodeModuleModule.class).setRequireRootDirectory(localRelativePath);
            nodeRuntime.getNodeModule(NodeModuleProcess.class).setWorkingDirectory(localRelativePath);

            String script = FileUtils.getAsOpen("node.js");
            script = script.replaceAll("//.*", "");
            nodeRuntime.getExecutor(script).executeVoid();

            File phpFile = FileUtils.findFileInDirectory(App.getInstance().getFilesDir() + "/plugin", "php");
            if (phpFile != null) {
                String path = phpFile.getParent() + ":" + phpFile.getParent() + "/libs";
                String phpEnvScript = "process.env.PATH=`${process.env.PATH}:%s`;\nprocess.env.LD_LIBRARY_PATH=`${process.env.LD_LIBRARY_PATH || ''}:%s`;";
                phpEnvScript = String.format(phpEnvScript, path, path);
//                LOG.e("node", phpEnvScript);
                nodeRuntime.getExecutor(phpEnvScript).executeVoid();
            }

            JavetBuiltInModuleResolver nodeResolve = new JavetBuiltInModuleResolver();
            nodeRuntime.setV8ModuleResolver(new IV8ModuleResolver() {
                @Override
                public IV8Module resolve(V8Runtime v8Runtime, String resourceName, IV8Module v8ModuleReferrer) {
                    try {
                        if (resourceName.startsWith("/") || resourceName.startsWith("./") || resourceName.startsWith("../")) {
                            File parentModuleName = new File(v8ModuleReferrer.getResourceName());
                            File moduleRelativePath = new File(parentModuleName.getParent(), resourceName);
                            File moduleFile = moduleRelativePath.getCanonicalFile();
                            String url = moduleFile.getCanonicalPath();

                            LOG.i(TAG2, "resourceName: " + resourceName + " -->> " + parentModuleName.getCanonicalPath() + "\n" +
                                    "resourceFile： " + url);
                            if (moduleFile.exists() && moduleFile.isFile()) {
                                String fixUrl = "file://" + url;
                                if (moduleCacheMap.containsKey(fixUrl)) {
                                    return moduleCacheMap.get(fixUrl);
                                } else {
                                    String code = FileUtils.readFileToString(moduleFile.getAbsolutePath());
                                    IV8Executor iV8Executor = v8Runtime.getExecutor("import.meta.url='" + fixUrl + "';var globalThis=__createGlobalImport__(import.meta.url);" + code);
                                    //iV8Executor.setResourceName(url); // 会改变路径
                                    iV8Executor.getV8ScriptOrigin().setResourceName(url); // 不会改变路径
                                    IV8Module compiled = iV8Executor.setModule(true).compileV8Module();
                                    moduleCacheMap.put(fixUrl, compiled);
                                    return compiled;
                                }
                            } else {
                                LOG.e(TAG2, "文件未找到: " + moduleFile.getAbsolutePath());
                                return null;
                            }
                        } else if (resourceName.startsWith("node:")) {
                            LOG.i(TAG2, "resourceName: " + resourceName + " -->> " + v8ModuleReferrer.getResourceName());
                            return nodeResolve.resolve(v8Runtime, resourceName, v8ModuleReferrer);
                        } else {
                            LOG.i(TAG2, "resourceName: " + resourceName + " -->> " + v8ModuleReferrer.getResourceName());
                            V8ValueObject moduleObject = ((NodeRuntime) v8Runtime).getNodeModule(resourceName, NodeModuleModule.class).getModuleObject();
                            moduleObject.set("default", moduleObject);
                            return v8Runtime.createV8Module(resourceName, moduleObject);
                        }
                    } catch (Exception e) {
                        LOG.e(TAG2, e);
                    }
                    return null;
                }

                @Override
                public String getAbsoluteResourceName(V8Runtime v8Runtime, String resourceName, IV8Module v8ModuleReferrer) throws JavetException {
                    LOG.i(TAG2, "getAbsoluteResourceName: " + resourceName);
//                    LOG.w(TAG, resourceName, "加载前目录： " + nodeRuntime.getNodeModule(NodeModuleProcess.class).getWorkingDirectory());
                    return resourceName;
                }
            });

            return nodeRuntime;
        } catch (Throwable e) {
            // 捕获所有类型的异常（包括 Error 和 Exception）
            System.out.println("捕获到异常: " + e);
            LOG.e(TAG, e);
        }
        return null;
    }

    public void internalNodeJSWrapper(String resourceName) {
        try {
            if (!resourceName.endsWith(".js")) {
                resourceName = new File(resourceName, "localt5.js").getAbsolutePath();
            }
            File resourceFile = new File(resourceName);
            String project = resourceFile.getParent();
            if (!resourceFile.exists()) {
                LOG.e(TAG, "没有找到服务文件：" + resourceFile.getAbsolutePath());
                isWorking.set(false);
                return;
            }
            String code = FileUtils.readFileToString(resourceName);
            if (TextUtils.isEmpty(code)) {
                LOG.e(TAG, "没有读取到服务脚本: " + resourceName);
                isWorking.set(false);
                return;
            }
            if (nodeRuntime == null) {
                nodeRuntime = createRuntime(project, resourceName);
                if (nodeRuntime == null) {
                    LOG.e(TAG, " NodeRuntime创建失败");
                    isWorking.set(false);
                    return;
                }
            } else {
                LOG.e(TAG, " 服务停止动作还未完成: " + resourceName);
                isWorking.set(false);
                return;
            }
            LOG.i(TAG, "executeVoid");
            isWorking.set(true);
            IV8Executor iV8Executor = nodeRuntime.getExecutor(
                    "let gimport = globalThis.import;\n" +
                    "delete globalThis.import;\n" +
                    "delete globalThis.__dirname;\n" +
                    "delete globalThis.__filename;\n" +
                    "gimport('" + resourceName + "');\n" +
                    "setInterval(() => {}, 60000); // 保持进程运行，不影响其他操作")
                    .setModule(true);
            iV8Executor.setResourceName(resourceName);
            iV8Executor.executeVoid();
            LOG.i(TAG, "node启动： nodeRuntime await");
            toast("node启动");

            runState.set(false);
            while (isWorking.get()) {
                synchronized (lock) {
                    try {
                        // 检查运行时状态
                        boolean hasPendingTasks = nodeRuntime.await(V8AwaitMode.RunNoWait);
                        if (!hasPendingTasks) {
                            // 没有任务时的处理
                            consecutiveIdleCycles++;
                            // 检查是否长时间空闲
                            long idleDuration = System.currentTimeMillis() - lastWorkTimestamp;
                            // 如果空闲超过外层定时器间隔的2倍，考虑深度睡眠
                            if (idleDuration > OUTER_TIMER_INTERVAL * 2) {
                                // 深度空闲，等待更长时间
                                int waitTime = Math.min(1000, (int)(idleDuration / 100));
                                LOG.i(TAG, "深度空闲，等待" + waitTime + "ms");
                                lock.wait(waitTime);
                            } else if (consecutiveIdleCycles > MAX_CONSECUTIVE_IDLE) { // 如果连续空闲周期超过阈值
                                LOG.i(TAG, "超过最大空闲周期，检查状态");
                                // 可以在这里添加状态检查或恢复逻辑
                                consecutiveIdleCycles = 0;
                                lock.wait(BASE_WAIT_TIME * 2);
                            } else {
                                // 正常空闲等待
                                lock.wait(BASE_WAIT_TIME);
                            }
                        } else {
                            // 有任务时的处理
                            consecutiveIdleCycles = 0;
                            lastWorkTimestamp = System.currentTimeMillis();
                            // 有任务时使用较短等待
                            lock.wait(Math.max(10, BASE_WAIT_TIME / 2));
                        }

                        if (listener != null && !runState.get()) {
                            listener.state(true);
                        }
                        runState.set(true);
                    } catch (InterruptedException e) {
                        LOG.e(TAG, "工作线程被中断" + e);
                        isWorking.set(false);
                        break;
                    } catch (Exception e) {
                        LOG.w(TAG, "运行时异常" + e);
                        // 根据错误类型决定是否继续
                        try {
                            lock.wait(1000); // 出错后等待1秒再尝试
                        } catch (InterruptedException ie) {
                            isWorking.set(false);
                            break;
                        }
                    }
                }
            }
        } catch (Throwable e) {
            // 捕获所有类型的异常（包括 Error 和 Exception）
            System.out.println("捕获到异常: " + e);
            LOG.e(TAG, e);
        } finally {
            isWorking.set(false);
            if (nodeRuntime != null) {
                nodeRuntime.lowMemoryNotification();
                LOG.w(TAG, "nodeRuntime close");
                try {
                    nodeRuntime.close();
                } catch (JavetException e) {
                    LOG.e(TAG, e);
                }
                nodeRuntime = null;
            }
            moduleCacheMap.clear();
            LOG.w(TAG,  "node已停止");
            toast("node已停止");

            isWorking.set(false);
            if (listener != null) {
                listener.state(false);
            }
        }
    }

    private void toast(String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(App.getInstance(), msg, Toast.LENGTH_SHORT).show();
            }
        });
    }

    public String normalize(String path) {
        // 将路径分割成各个部分
        String[] components = path.split(File.separator);
        Stack<String> stack = new Stack<>();
        for (String component : components) {
            if (component.equals("..")) {
                if (!stack.isEmpty() && !stack.peek().equals("..")) {
                    stack.pop();  // 上一级目录
                }
            } else if (!component.equals(".") && !component.isEmpty()) {
                stack.push(component);  // 仅当不是 "." 或空字符串时才加入
            }
        }
        // 构建规范化后的路径
        StringBuilder normalizedPath = new StringBuilder();
        for (String component : stack) {
            normalizedPath.append(File.separator).append(component);
        }
        // 如果路径以根目录开始（如 Unix 系统中的 `/`），则加上根路径
        if (path.startsWith(File.separator)) {
            normalizedPath.insert(0, File.separator);
        }
        return normalizedPath.toString();
    }

}