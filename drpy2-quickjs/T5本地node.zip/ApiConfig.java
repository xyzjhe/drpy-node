
    public Spider getCSP(SourceBean sourceBean) {
        if (sourceBean.isJsApi()) {
            return jsLoader.getSpider(sourceBean.getKey(), sourceBean.getApi(), sourceBean.getExt(), sourceBean.getJar());
        } else if (sourceBean.isPyApi()) {
            return pyLoader.getSpider(sourceBean.getKey(), sourceBean.getApi(), sourceBean.getExt());
        } else if (sourceBean.isNodeApi()) {
            return nodeLoader.getSpider(sourceBean.getKey(), sourceBean.getApi(), sourceBean.getExt());
        } else {
            return jarLoader.getSpider(sourceBean.getKey(), sourceBean.getApi(), sourceBean.getExt(), sourceBean.getJar());
        }
    }
	
    public Object[] proxyLocal(Map<String, String> params) {
        try {
            String doStr = params.get("do");
            if (doStr != null && doStr.equals("live")) {
                String type = params.get("type");
                if (type != null && type.equals("txt")) {
                    String ext = params.get("ext");
                    ext = new String(Base64.decode(ext, Base64.DEFAULT | Base64.URL_SAFE | Base64.NO_WRAP), "UTF-8");
                    return TxtSubscribe.load(ext);
                }
                return null;
            }

            Map<String, String> treeParams = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
            treeParams.putAll(params);
            String sourceKey = treeParams.get("siteKey");
            if (sourceKey == null) sourceKey = treeParams.get("sourcekey");
            if (sourceKey == null) sourceKey = ApiConfig.get().getHomeSourceBean().getKey();

            SourceBean sourceBean = ApiConfig.get().getSource(sourceKey);
            if (sourceBean == null) return null;

            if (sourceBean.isJsApi()) {
                return jsLoader.proxyInvoke(params);
            } else if (sourceBean.isPyApi()) {
                return pyLoader.proxyInvoke(params);
            } else if (sourceBean.isNodeApi()) {
                return nodeLoader.proxyInvoke(params);
            } else {
                return jarLoader.proxyInvoke(params);
            }
        } catch (Exception e) {
            LOG.e("proxyLocal", e);
        }
        return null;
    }

